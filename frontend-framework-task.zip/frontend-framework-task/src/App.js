import React from "react";
import Header from "./components/Header";
import Card from "./components/Card";
import Counter from "./components/Counter";
import "./App.css";

function App() {
  return (
    <div className="app">
      <Header title="Frontend Framework Basics" />

      <div className="container">
        <Card
          name="React.js"
          description="React is a JavaScript library for building user interfaces."
        />

        <Counter />
      </div>
    </div>
  );
}

export default App;