# Frontend Framework Basics - React

## Objective
Learn React component architecture, Props, and State.

## Features
- Functional Components
- Props
- useState Hook
- Simple UI

## Tools Used
- React.js
- JavaScript
- CSS

## How to Run
1. Install Node.js
2. Open terminal
3. Run:
   npm install
   npm start
