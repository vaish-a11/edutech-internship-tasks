# Task 7 — Backend Environment Setup

**Edutech Full Stack Development Internship**

## What I Did

Set up a basic Node.js + Express backend server with environment variable support using `dotenv`.

## Tech Stack

- **Node.js** — JavaScript runtime
- **Express** — Web framework
- **dotenv** — Environment variable management

## Project Structure

```
task7-backend/
├── server.js        # Main Express server
├── package.json     # Project metadata & dependencies
├── .env             # Environment variables (not committed)
├── .env.example     # Template for env variables
├── .gitignore       # Ignores node_modules and .env
└── README.md
```

## How to Run

```bash
# 1. Install dependencies
npm install

# 2. Create your .env file
cp .env.example .env

# 3. Start the server
npm start

# Or with auto-reload during development
npm run dev
```

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/` | Welcome message + server info |
| GET | `/api/status` | App status & uptime |

## Interview Q&A

**What is Node.js?**  
Node.js is a JavaScript runtime built on Chrome's V8 engine. It lets you run JavaScript on the server side, outside the browser, and is known for its non-blocking, event-driven architecture.

**What is package.json?**  
`package.json` is the manifest file for a Node.js project. It stores project metadata (name, version, description), lists dependencies, and defines npm scripts like `start` and `dev`.
