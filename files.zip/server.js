// server.js — Task 7: Backend Environment Setup
// Edutech Full Stack Development Internship

// Load environment variables from .env file
require("dotenv").config();

const express = require("express");

const app = express();

// ──────────────────────────────────────────────
// Middleware
// ──────────────────────────────────────────────
app.use(express.json());          // Parse incoming JSON bodies
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded bodies

// ──────────────────────────────────────────────
// Environment Variables
// ──────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
const NODE_ENV = process.env.NODE_ENV || "development";
const APP_NAME = process.env.APP_NAME || "Edutech Backend";

// ──────────────────────────────────────────────
// Routes
// ──────────────────────────────────────────────

// Health-check / root route
app.get("/", (req, res) => {
  res.json({
    message: `Welcome to ${APP_NAME}`,
    environment: NODE_ENV,
    status: "Server is running successfully",
    timestamp: new Date().toISOString(),
  });
});

// API status route
app.get("/api/status", (req, res) => {
  res.json({
    success: true,
    app: APP_NAME,
    version: "1.0.0",
    environment: NODE_ENV,
    uptime: `${Math.floor(process.uptime())} seconds`,
  });
});

// 404 handler — catch unmatched routes
app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

// ──────────────────────────────────────────────
// Start Server
// ──────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`✅ Server is running on http://localhost:${PORT}`);
  console.log(`🌍 Environment : ${NODE_ENV}`);
  console.log(`📦 App Name    : ${APP_NAME}`);
});
