async function loadUsers() {
  const loading = document.getElementById("loading");
  const usersDiv = document.getElementById("users");

  loading.innerText = "Loading data...";
  usersDiv.innerHTML = "";

  try {
    const response = await axios.get("https://jsonplaceholder.typicode.com/users");

    response.data.forEach(user => {
      const div = document.createElement("div");
      div.className = "user-card";
      div.innerHTML = `
        <h3>${user.name}</h3>
        <p><strong>Email:</strong> ${user.email}</p>
        <p><strong>City:</strong> ${user.address.city}</p>
      `;
      usersDiv.appendChild(div);
    });

    loading.innerText = "Data Loaded Successfully!";
  } catch (error) {
    loading.innerText = "Error fetching data!";
    console.error(error);
  }
}
