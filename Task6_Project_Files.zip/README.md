# Task 6 - Consuming REST APIs with Fetch/Axios

## Objective
This project demonstrates how to consume REST APIs using Axios.

## Features
- Fetch user data from JSONPlaceholder API
- Display data dynamically
- Loading state handling
- Error handling

## Technologies Used
- HTML
- CSS
- JavaScript
- Axios
- JSONPlaceholder API

## Run the Project
1. Download the project
2. Open index.html in browser
3. Click 'Load Users'
